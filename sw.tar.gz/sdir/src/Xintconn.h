
#ifndef _XINTCONN_H_
#define _XINTCONN_H_ 1

#include <X11/Xfuncproto.h>
#include <X11/Xlib.h>

_XFUNCPROTOBEGIN

/* OpenDis.c */
extern void _XFreeDisplayStructure(Display *dpy);

_XFUNCPROTOEND

#endif /* _XINTCONN_H_ */
